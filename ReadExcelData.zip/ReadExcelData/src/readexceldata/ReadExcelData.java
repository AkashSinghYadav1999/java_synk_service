  
package readexceldata;
 
import java.io.*;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class ReadExcelData {
 
    public static void main(String[] args) {
        //parsing a CSV file into Scanner class constructor  
        try{
        Scanner sc = new Scanner(new File("C:\\Users\\pc\\Documents\\Myjava\\NetBeansProjects\\ReadExcelData\\src\\readexceldata\\AssignmentSheet.csv"));  
         
         String query="INSERT INTO readcsvexample (timestamp,ver,product_family,country,device_type,os,checkout_failure_count,payment_api_failure_count,purchase_count,revenue) VALUES ";
          String query1="";
        sc.hasNext();
        sc.next();
        boolean flag=true;
        while (sc.hasNext())  //returns a boolean value  
        {    
            String s= sc.next();
            if(sc.hasNext()){
             String s1= sc.next();
            String[] tokens=s1.split(",");  
            tokens[0]=s+" "+tokens[0];
            if(flag){ 
            query1=query1+"(";
            flag=false;
            }else{
            query1=query1+",(";
            }
            boolean flag1=true;
            for(String value : tokens){
                if(flag1){
                    query1=query1+"'"+value+"'";
                    flag1=false;
                }else{
                        query1=query1+",'"+value+"'";
                }
            }
            query1=query1+")";
               // System.out.println(query1);  
            }
        }   
        sc.close();  //closes the scanner  
        
        
        try{
            Connection con=MyConnection.getCon();
            Statement stmt=con.createStatement();
            query=query+query1;
            int result=stmt.executeUpdate(query);            
            System.out.println(result+" Record Inserted Successfully.");  
        }catch(SQLException se){
           se.printStackTrace();
        } 
        
        
        
        }catch(FileNotFoundException fe){
            fe.printStackTrace();
        }
    }
    
}
